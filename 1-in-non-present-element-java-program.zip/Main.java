import java.util.*;
public class Main{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
int l=sc.nextInt();
ArrayList<Integer>al=new ArrayList<Integer>();
for(int i=0;i<l;i++){
int c=sc.nextInt();
al.add(c);
}
Collections.sort(al);
int n=al.get(l-1);
for(int i=0;i<n;i++){
if(al.get(i)!=i)
al.add(i,-1);
}
for(Integer k:al)
System.out.print(k+" ");
}}